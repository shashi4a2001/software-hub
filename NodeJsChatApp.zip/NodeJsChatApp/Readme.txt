NodeJsChat server with following features:
---------------------------------------------
1. New user Registration
2. Signin with Userid and password
3. Online/Offline users list
4. Chat with availabel users
5. Chat message non-delivery response
6. SignOut feature
7. UserMaster Database in plain text file



Files
------------
Server.js - This is the chat server
URL to access chat after running server : http://localhost:3000
Available user: userid: user1  password:1234
